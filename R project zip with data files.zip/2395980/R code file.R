# Name: Jay Joshi 
# Student id: 200440993
# This program is an implementation for hypothesis Testing 

# Hypothesis Testing 1: To study the effect of task determinability on user interaction with experimental interface compared to
# baseline interface

# Data Preparation: Read the csv of number of documents saved by user for unspecified task on experimental and basleine interface.
# Remember interface is within-subject variable 


# Hypothesis testing for unspecified and specified task for documents, query and measurement of time 

unspecified.documents=read.csv("Number of Documents for Unspecific Task.csv")
unspecified.documents
unspecified.documents.describe<- unspecified.documents %>%
  gather(key = "interface", value = "Documents.of.Unspecified.Task", Documents..Klink.Search.Interface, Documents..IEEE.search.Interface) %>%
  convert_as_factor(Participant_id, interface)
unspecified.documents.describe

unspecified.documents.describe %>%
  group_by(interface) %>%
  get_summary_stats(Documents.of.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.documents.describe, x = "interface", y = "Documents.of.Unspecified.Task", add = "point")
box_plot
unspecified.documents.describe %>%
  group_by(interface) %>%
  shapiro_test(Documents.of.Unspecified.Task)

unspecified.documents.aov <- anova_test(data = unspecified.documents.describe, dv = Documents.of.Unspecified.Task, wid = Participant_id, within = interface)
get_anova_table(unspecified.documents.aov)
data_frame=read.csv("Number of Documents for Unspecific Task.csv")
test=wilcox.test(unspecified.documents $Documents..Klink.Search.Interface, unspecified.documents $Documents..IEEE.search.Interface, paired = TRUE)
Zstat<-qnorm(test$p.value/2)
Zstat

test
test $parameter
test $statistic
wilcox.test <- list(statistic = STATISTIC,
             parameter = NULL,
             p.value = as.numeric(PVAL),
             null.value = mu,
             alternative = alternative,
             method = METHOD,
             z_val = z,
             data.name = DNAME)

# Specified Task Hypothesis for number of documents 

specified.documents=read.csv("Number of Documents for Specified Task.csv")
specified.documents
specified.describe<- specified.documents %>%
  gather(key = "interface", value = "Documents.of.Specified.Task", Documents.for.Klink.Search.Interface ,  Documents.for.IEEE.Search.Interface) %>%
  convert_as_factor(Participant_id, interface)
specified.describe
specified.describe %>%
  group_by(interface) %>%
  get_summary_stats(Documents.of.Specified.Task, type = "mean_sd")
box_plot <- ggboxplot(specified.describe, x = "interface", y = "Documents.of.Specified.Task", add = "point")
box_plot
specified.describe %>%
  group_by(interface) %>%
  shapiro_test(Documents.of.Specified.Task)
res.aov <- anova_test(data = specified.describe, dv = Documents.of.Specified.Task, wid = Participant_id, within = interface)
get_anova_table(res.aov)
specified.test=wilcox.test(specified.documents $Documents.for.Klink.Search.Interface, specified.documents $Documents.for.IEEE.Search.Interface, paired = TRUE)
specified.test


# UnSpecified Task Hypothesis for number of queries 

unspecified.queries=read.csv("Number of queries for unspecified Task.csv")
unspecified.queries
unspecified.queries.describe<- unspecified.queries %>%
  gather(key = "interface", value = "Queries.of.Unspecified.Task", Queries.for.Klink.Search.Interface, Queries.for.IEEE.Search.Interface) %>%
  convert_as_factor(Participant_id, interface)
unspecified.queries
unspecified.queries.describe
unspecified.queries.describe %>%
  group_by(interface) %>%
  get_summary_stats(Queries.of.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.queries.describe, x = "interface", y = "Queries.of.Unspecified.Task", add = "point")
box_plot
unspecified.queries.describe %>%
  group_by(interface) %>%
  shapiro_test(Queries.of.Unspecified.Task)
unspecified.queries.aov <- anova_test(data = unspecified.queries.describe, dv = Queries.of.Unspecified.Task, wid = Participant_id, within = interface)
get_anova_table(unspecified.queries.aov)
unspecified.queries.test=wilcox.test(unspecified.queries $Queries.for.Klink.Search.Interface, unspecified.queries $Queries.for.IEEE.Search.Interface, paired = TRUE)
unspecified.queries.test
Zstat<-qnorm(unspecified.queries.test $p.value/2)
Zstat



# Specified Task Hypothesis for number of queries 

specified.queries=read.csv("Number of queries for specified Task.csv")
specified.queries
specified.queries.describe<- specified.queries %>%
  gather(key = "interface", value = "Queries.of.Specified.Task", Queries.for.Klink.Search.Interface, Quereis.for.IEEE.Search.Interface) %>%
  convert_as_factor(Participant_id, interface)
specified.queries
specified.queries.describe
specified.queries.describe %>%
  group_by(interface) %>%
  get_summary_stats(Queries.of.Specified.Task, type = "mean_sd")
box_plot <- ggboxplot(specified.queries.describe, x = "interface", y = "Queries.of.Specified.Task", add = "point")
box_plot
specified.queries.describe %>%
  group_by(interface) %>%
  shapiro_test(Queries.of.Specified.Task)
specified.queries.aov <- anova_test(data = specified.queries.describe, dv = Queries.of.Specified.Task, wid = Participant_id, within = interface)
get_anova_table(specified.queries.aov)
specified.queries.test=wilcox.test(specified.queries $Queries.for.Klink.Search.Interface, specified.queries $Quereis.for.IEEE.Search.Interface, paired = TRUE)
specified.queries.test
Zstat<-qnorm(specified.queries.test $p.value/2)
Zstat


# UnSpecified Task Hypothesis for time spent 

unspecified.time=read.csv("Time for Unspecified Task.csv")
unspecified.time
unspecified.time.describe<- unspecified.time %>%
  gather(key = "interface", value = "Time.taken.for.Unspecified.Task", Time.spent.on.Klink.Search.Interface, Time.spent.on.IEEE.Search.Interface) %>%
  convert_as_factor(Participant_id, interface)
unspecified.queries
unspecified.time.describe
unspecified.time.describe %>%
  group_by(interface) %>%
  get_summary_stats(Time.taken.for.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.time.describe, x = "interface", y = "Time.taken.for.Unspecified.Task", add = "point")
box_plot
unspecified.time.describe %>%
  group_by(interface) %>%
  shapiro_test(Time.taken.for.Unspecified.Task)
unspecified.time.aov <- anova_test(data = unspecified.time.describe, dv = Time.taken.for.Unspecified.Task, wid = Participant_id, within = interface)
get_anova_table(unspecified.time.aov)
unspecified.time.test=wilcox.test(unspecified.time $Time.spent.on.Klink.Search.Interface, unspecified.time $Time.spent.on.IEEE.Search.Interface, paired = TRUE)
unspecified.time.test
Zstat<-qnorm(unspecified.time.test $p.value/2)
Zstat

# UnSpecified Task Hypothesis for time spent 

specified.time=read.csv("Time taken for specified task.csv")
specified.time
specified.time.describe<- specified.time %>%
  gather(key = "interface", value = "Time.taken.for.Specified.Task", Time.spent.on.Klink.Search.Interface, Time.spent.on.IEEE.Search.Interface) %>%
  convert_as_factor(Particpant_id, interface)
unspecified.queries
specified.time.describe
specified.time.describe %>%
  group_by(interface) %>%
  get_summary_stats(Time.taken.for.Specified.Task, type = "mean_sd")
box_plot <- ggboxplot(specified.time.describe, x = "interface", y = "Time.taken.for.Specified.Task", add = "point")
box_plot
specified.time.describe %>%
  group_by(interface) %>%
  shapiro_test(Time.taken.for.Specified.Task)

specified.time.aov <- anova_test(data = specified.time.describe, dv = Time.taken.for.Specified.Task, wid = Particpant_id, within = interface)
get_anova_table(specified.time.aov)
specified.time.test=wilcox.test(specified.time $Time.spent.on.Klink.Search.Interface, specified.time $Time.spent.on.IEEE.Search.Interface, paired = TRUE)
specified.time.test
Zstat<-qnorm(specified.time.test $p.value/2)
Zstat



# Hypothesis testing for user engagement scale: Focused Attention, Perceived Usability, Search Effectiveness and Reward

# Unspecified Task Focused Attention Measure 

klink=read.csv("Klink unspecified user engagement.csv")
IEEE=read.csv("IEEE unspecified code.csv")
data.frame.focused.attention=data.frame(klink $Participant_id, klink $Focused.Attention.for.Klink, IEEE $Focused.Attention.for.IEEE)
data.frame.focused.attention
klink
IEEE
unspecified.focused.attention.describe<- data.frame.focused.attention %>%
  gather(key = "interface", value = "Focused.Attention.Unspecified.Task", klink.Focused.Attention.for.Klink,IEEE.Focused.Attention.for.IEEE) %>%
  convert_as_factor( klink.Participant_id, interface)
unspecified.focused.attention.describe
unspecified.focused.attention.describe %>%
  group_by(interface) %>%
  get_summary_stats(Focused.Attention.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.focused.attention.describe, x = "interface", y = "Focused.Attention.Unspecified.Task", add = "point")
box_plot
unspecified.focused.attention.describe %>%
  group_by(interface) %>%
  shapiro_test(Focused.Attention.Unspecified.Task)
unspecified.focused.attention.aov <- anova_test(data = unspecified.focused.attention.describe, dv = Focused.Attention.Unspecified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(unspecified.focused.attention.aov)
unspecified.focused.attention.test=wilcox.test(data.frame.focused.attention $klink.Focused.Attention.for.Klink, data.frame.focused.attention $IEEE.Focused.Attention.for.IEEE, paired = TRUE)
unspecified.focused.attention.test
Zstat<-qnorm(specified.focused.attention.test $p.value/2)
Zstat

# Unspecified Task Perceived Usability  Measure

klink=read.csv("Klink unspecified user engagement.csv")
IEEE=read.csv("IEEE unspecified code.csv")
data.frame.perceived.usability=data.frame(klink $Participant_id, klink $Percieved.Usability.for.Klink/3, IEEE $Perceived.Usability.for.IEEE/3)
data.frame.perceived.usability
klink
IEEE
unspecified.perceived.usability.describe<- data.frame.perceived.usability %>%
  gather(key = "interface", value = "perceived.usability.Unspecified.Task", klink.Percieved.Usability.for.Klink.3,IEEE.Perceived.Usability.for.IEEE.3) %>%
  convert_as_factor( klink.Participant_id, interface)
unspecified.perceived.usability.describe
unspecified.perceived.usability.describe %>%
  group_by(interface) %>%
  get_summary_stats(perceived.usability.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.perceived.usability.describe, x = "interface", y = "perceived.usability.Unspecified.Task", add = "point")
box_plot
unspecified.perceived.usability.describe %>%
  group_by(interface) %>%
  shapiro_test(perceived.usability.Unspecified.Task)
unspecified.perceived.usability.aov <- anova_test(data = unspecified.perceived.usability.describe, dv = perceived.usability.Unspecified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(unspecified.perceived.usability.aov)
unspecified.perceived.attention.test=wilcox.test(data.frame.perceived.usability $klink.Percieved.Usability.for.Klink.3, data.frame.perceived.usability $IEEE.Perceived.Usability.for.IEEE.3, paired = TRUE)
unspecified.perceived.attention.test
Zstat<-qnorm(unspecified.perceived.attention.test $p.value/2)
Zstat

# Unspecified Task Search Effectiveness Measure

klink=read.csv("Klink unspecified user engagement.csv")
IEEE=read.csv("IEEE unspecified code.csv")
data.frame.search.eff=data.frame(klink $Participant_id, klink $Search.Effectiveness.for.Klink/5, IEEE $Search.Effectiveness.for.IEEE/5)
data.frame.search.eff
klink
IEEE
unspecified.search.effective.describe<- data.frame.search.eff %>%
  gather(key = "interface", value = "search.effective.Unspecified.Task",klink.Search.Effectiveness.for.Klink.5, IEEE.Search.Effectiveness.for.IEEE.5) %>%
  convert_as_factor( klink.Participant_id, interface)
unspecified.search.effective.describe
unspecified.search.effective.describe %>%
  group_by(interface) %>%
  get_summary_stats(search.effective.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.search.effective.describe, x = "interface", y = "search.effective.Unspecified.Task", add = "point")
box_plot
unspecified.search.effective.describe %>%
  group_by(interface) %>%
  shapiro_test(search.effective.Unspecified.Task)
unspecified.search.effective.aov <- anova_test(data = unspecified.search.effective.describe, dv = search.effective.Unspecified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(unspecified.search.effective.aov)
unspecified.search.effective.test=wilcox.test(data.frame.search.eff $klink.Search.Effectiveness.for.Klink.5, data.frame.search.eff $IEEE.Search.Effectiveness.for.IEEE.5, paired = TRUE)
unspecified.search.effective.test
Zstat<-qnorm(unspecified.search.effective.test $p.value/2)
Zstat

# Unspecified Task Reward Measure

klink=read.csv("Klink unspecified user engagement.csv")
IEEE=read.csv("IEEE unspecified code.csv")
data.frame.reward=data.frame(klink $Participant_id, klink $Reward.for.Klink/3, IEEE $Reward.for.IEEE/3)
data.frame.reward
klink
IEEE
unspecified.reward.describe<- data.frame.reward %>%
  gather(key = "interface", value = "Reward.Unspecified.Task",klink.Reward.for.Klink.3, IEEE.Reward.for.IEEE.3) %>%
  convert_as_factor( klink.Participant_id, interface)
unspecified.reward.describe
unspecified.reward.describe %>%
  group_by(interface) %>%
  get_summary_stats(Reward.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.reward.describe, x = "interface", y = "Reward.Unspecified.Task", add = "point")
box_plot
unspecified.reward.describe %>%
  group_by(interface) %>%
  shapiro_test(Reward.Unspecified.Task)
unspecified.reward.aov <- anova_test(data = unspecified.reward.describe, dv = Reward.Unspecified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(unspecified.reward.aov)
unspecified.reward.test=wilcox.test(data.frame.reward $klink.Reward.for.Klink.3, data.frame.reward $IEEE.Reward.for.IEEE.3, paired = TRUE)
unspecified.reward.test
Zstat<-qnorm(unspecified.reward.test $p.value/2)
Zstat



klink=read.csv("Klink unspecified user engagement.csv")
IEEE=read.csv("IEEE unspecified code.csv")
data.frame.focused.attention=data.frame(klink $Participant_id, klink $Focused.Attention.for.Klink/3, IEEE $Focused.Attention.for.IEEE/3)
data.frame.focused.attention
klink
IEEE
unspecified.focused.attention.describe<- data.frame.focused.attention %>%
  gather(key = "interface", value = "Focused.Attention.Unspecified.Task", klink.Focused.Attention.for.Klink.3,IEEE.Focused.Attention.for.IEEE.3) %>%
  convert_as_factor( klink.Participant_id, interface)
unspecified.focused.attention.describe
unspecified.focused.attention.describe %>%
  group_by(interface) %>%
  get_summary_stats(Focused.Attention.Unspecified.Task, type = "mean_sd")
box_plot <- ggboxplot(unspecified.focused.attention.describe, x = "interface", y = "Focused.Attention.Unspecified.Task", add = "point")
box_plot
unspecified.focused.attention.describe %>%
  group_by(interface) %>%
  shapiro_test(Focused.Attention.Unspecified.Task)
unspecified.focused.attention.aov <- anova_test(data = unspecified.focused.attention.describe, dv = Focused.Attention.Unspecified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(unspecified.focused.attention.aov)
unspecified.focused.attention.test=wilcox.test(data.frame.focused.attention $klink.Focused.Attention.for.Klink.3, data.frame.focused.attention $IEEE.Focused.Attention.for.IEEE.3, paired = TRUE)
unspecified.focused.attention.test
Zstat<-qnorm(unspecified.focused.attention.test$p.value/2)
Zstat


# Specified Task Focused Attention Measure


klink=read.csv("klink search specified task.csv")
IEEE=read.csv("IEEE specified task code.csv")
data.frame.focused.attention=data.frame(klink $Participant_id, klink $Focused.Attention/3, IEEE $Focused.Attention/3)
data.frame.focused.attention
klink
IEEE
specified.focused.attention.describe<- data.frame.focused.attention %>%
  gather(key = "interface", value = "Focused.Attention.Specified.Task", klink.Focused.Attention.3,IEEE.Focused.Attention.3) %>%
  convert_as_factor( klink.Participant_id, interface)
specified.focused.attention.describe
specified.focused.attention.describe %>%
  group_by(interface) %>%
  get_summary_stats(Focused.Attention.Specified.Task, type = "mean_sd")
box_plot <- ggboxplot(specified.focused.attention.describe, x = "interface", y = "Focused.Attention.Specified.Task", add = "point")
box_plot
specified.focused.attention.describe %>%
  group_by(interface) %>%
  shapiro_test(Focused.Attention.Specified.Task)
specified.focused.attention.aov <- anova_test(data = specified.focused.attention.describe, dv = Focused.Attention.Specified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(specified.focused.attention.aov)
specified.focused.attention.test=wilcox.test(data.frame.focused.attention $klink.Focused.Attention.3, data.frame.focused.attention $IEEE.Focused.Attention.3, paired = TRUE)
specified.focused.attention.test
Zstat<-qnorm(specified.focused.attention.test $p.value/2)
Zstat

# Unspecified Task Perceived Usability Measure

klink=read.csv("klink search specified task.csv")
IEEE=read.csv("IEEE specified task code.csv")
data.frame.perceived.usability=data.frame(klink $Participant_id, klink $Percieved.Usability/3, IEEE $Perceived.Usability/3)
data.frame.perceived.usability
klink
IEEE
specified.perceived.usability.describe<- data.frame.perceived.usability %>%
  gather(key = "interface", value = "perceived.usability.Specified.Task", klink.Percieved.Usability.3,IEEE.Perceived.Usability.3) %>%
  convert_as_factor( klink.Participant_id, interface)
specified.perceived.usability.describe
specified.perceived.usability.describe %>%
  group_by(interface) %>%
  get_summary_stats(perceived.usability.Specified.Task, type = "mean_sd")
box_plot <- ggboxplot(specified.perceived.usability.describe, x = "interface", y = "perceived.usability.Specified.Task", add = "point")
box_plot
specified.perceived.usability.describe %>%
  group_by(interface) %>%
  shapiro_test(perceived.usability.Specified.Task)
specified.perceived.usability.aov <- anova_test(data = specified.perceived.usability.describe, dv = perceived.usability.Specified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(specified.perceived.usability.aov)
specified.perceived.attention.test=wilcox.test(data.frame.perceived.usability $klink.Percieved.Usability.3, data.frame.perceived.usability $IEEE.Perceived.Usability.3, paired = TRUE)
specified.perceived.attention.test
Zstat<-qnorm(specified.perceived.attention.test$p.value/2)
Zstat


# Specified Task Search Effectiveness Measure

klink=read.csv("klink search specified task.csv")
IEEE=read.csv("IEEE specified task code.csv")
data.frame.search.eff=data.frame(klink $Participant_id, klink $Search.Effectiveness/5, IEEE $Search.Effectiveness/5)
data.frame.search.eff
klink
IEEE
specified.search.effective.describe<- data.frame.search.eff %>%
  gather(key = "interface", value = "search.effective.Specified.Task",klink.Search.Effectiveness.5, IEEE.Search.Effectiveness.5) %>%
  convert_as_factor( klink.Participant_id, interface)
specified.search.effective.describe
specified.search.effective.describe %>%
  group_by(interface) %>%
  get_summary_stats(search.effective.Specified.Task, type = "mean_sd")
box_plot <- ggboxplot(specified.search.effective.describe, x = "interface", y = "search.effective.Specified.Task", add = "point")
box_plot
specified.search.effective.describe %>%
  group_by(interface) %>%
  shapiro_test(search.effective.Specified.Task)
specified.search.effective.aov <- anova_test(data = specified.search.effective.describe, dv = search.effective.Specified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(specified.search.effective.aov)
specified.search.effective.test=wilcox.test(data.frame.search.eff $klink.Search.Effectiveness.5, data.frame.search.eff $IEEE.Search.Effectiveness.5, paired = TRUE)
specified.search.effective.test
Zstat<-qnorm(specified.search.effective.test$p.value/2)
Zstat

# Specified Task Reward  Measure


klink=read.csv("klink search specified task.csv")
IEEE=read.csv("IEEE specified task code.csv")
data.frame.reward=data.frame(klink $Participant_id, klink $Reward/3, IEEE $Reward/3)
data.frame.reward
klink
IEEE
specified.reward.describe<- data.frame.reward %>%
  gather(key = "interface", value = "Reward.Specified.Task",klink.Reward.3, IEEE.Reward.3) %>%
  convert_as_factor( klink.Participant_id, interface)
specified.reward.describe
specified.reward.describe %>%
  group_by(interface) %>%
  get_summary_stats(Reward.Specified.Task, type = "mean_sd")
box_plot <- ggboxplot(specified.reward.describe, x = "interface", y = "Reward.Specified.Task", add = "point")
box_plot
specified.reward.describe %>%
  group_by(interface) %>%
  shapiro_test(Reward.Specified.Task)
specified.reward.aov <- anova_test(data = specified.reward.describe, dv = Reward.Specified.Task, wid = klink.Participant_id, within = interface)
get_anova_table(specified.reward.aov)
specified.reward.test=wilcox.test(data.frame.reward $klink.Reward.3, data.frame.reward $IEEE.Reward.3, paired = TRUE)
specified.reward.test
Zstat<-qnorm(specified.reward.test$p.value/2)
Zstat
